from .spectral_energy_density import compute_sed


__all__ = ['compute_sed']
