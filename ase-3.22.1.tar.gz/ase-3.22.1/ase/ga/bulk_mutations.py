raise ImportError(
        'The ase.ga.bulk_mutations module has been deprecated. '
        'The same functionality is now provided by the '
        'ase.ga.standardmutations and ase.ga.soft_mutation modules. '
        'Please consult their documentation to verify how to initialize '
        'the different mutation operators.')
